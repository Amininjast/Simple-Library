//public class ManageLib {
//    private Library lib;//general or local
//    private static int membersCount = 0;
//    private static int booksCount = 0;
//    private static int BBcount = 0;
//
//    public Library getLib() {
//        return lib;
//    }
//
//    public synchronized void addLibrary(String name) {
//        lib = new Library();
//        lib.setName(name);
//    }
//
//    public Long addMember(Member member) {
//        Member newMember = new Member();
//        newMember.setName(member.getName());
//        newMember.setAge(member.getAge());
//        newMember.setSex(member.getSex());
//        if (membersCount < lib.getMembers().length) {
//            lib.getMembers()[membersCount] = newMember;
//            membersCount++;
//            return newMember.getMenberShipNo();
//        } else {
//            System.out.println("Library is full !!");
//            return null;
//        }
//    }
//
//
//    public Member findMemberById(long memberShipNo) {
//        for (Member member : lib.getMembers()) {
//            if (member.getMenberShipNo().equals(memberShipNo)) {
//                return member;
//            }
//        }
//        System.out.format("no user with the memberShip number %d%n found \n", memberShipNo);
//        return null;
//    }
//
//
//    public void editMember(long memberShipNo, Member editedMember) {
//        Member member = findMemberById(memberShipNo);
//        member.setName(editedMember.getName());
//        member.setAge(editedMember.getAge());
//        member.setSex(editedMember.getSex());
//    }
//
//    public void deleteMember(long memberShipNo) {
//        Member member = findMemberById(memberShipNo);
//        for (int i = 0; i < lib.getMembers().length; i++) {
//            if (member.equals(lib.getMembers()[i])) {
//                // shifting elements
//                for (int j = i; j < lib.getMembers().length - 1; j++) {
//                    lib.getMembers()[j] = lib.getMembers()[j + 1];
//                }
//                break;
//            }
//        }
//    }
//
//    public void deleteMember2(long memberShipNo) {
//        Member[] members = lib.getMembers();
//        Member member = findMemberById(memberShipNo);
//        Member[] proxyArray = new Member[lib.getMembers().length - 1];
//        int count = 0;
//        for (int i = 0; i < lib.getMembers().length - 1; i++) {
//            if (member.equals(lib.getMembers()[i])) {
//                continue;
//            }
//            proxyArray[count++] = members[i];
//        }
//        lib.setMembers(proxyArray);
//    }
//
//
//}
//-------------------------
//
//        اینجا منو هست
//public void processOptions(ManageLib manageLib) {
//        Integer choose = null;
//        this.ShowMenu();
//        do {
//        choose = scanner.nextInt();
//        switch (choose) {
//        case 1: {
//        getAndAddMember(manageLib);
//        break;
//        }
//        case 2: {
//        getAndEditMember(manageLib);
//        break;
//        }
//        case 3: {
//        System.out.print("enter memberShip number:");
//        long memberShipNo = scanner.nextLong();
//        System.out.println(manageLib.findMemberById(memberShipNo));
//        break;
//        }
//        case 4: {
//        System.out.print("enter memberShip number:");
//        long memberShipNo = scanner.nextLong();
//        manageLib.deleteMember2(memberShipNo);
//        System.out.println("delete was successful");
//        break;
//        }
//        case 5: {
//        System.out.println("these are all the members:");
//        System.out.println(Arrays.toString(showAllTheMembers(manageLib.getLib().getMembers())));
//        break;
//        }
//        }
//        } while (choose != 6);
//        }
//
//        void getAndAddMember(ManageLib manageLib) {
//        System.out.print("enter your name:");
//        String name = scanner.next();
//        System.out.print("enter your age:");
//        int age = scanner.nextInt();
//        System.out.print("choose:\n1.male\n2.female");
//        int chooseSex = scanner.nextInt();
//        Sex sex = null;
//        if (chooseSex == 1) {
//        sex = Sex.MALE;
//        } else if (chooseSex == 2) {
//        sex = Sex.FEMALE;
//        }
//        Member member = new Member(name, age, sex);
//        System.out.println("your memberShip number is:" + manageLib.addMember(member));
//        }
//
//        void getAndEditMember(ManageLib manageLib) {
//        System.out.print("enter your member ship number:");
//        long memberShipNo = scanner.nextLong();
//        System.out.print("enter your name:");
//        String name = scanner.next();
//        System.out.print("enter your age:");
//        int age = scanner.nextInt();
//        System.out.print("choose:\n1.male\n2.female");
//        int chooseSex = scanner.nextInt();
//        Sex sex = null;
//        if (chooseSex == 1) {
//        sex = Sex.MALE;
//        } else if (chooseSex == 2) {
//        sex = Sex.FEMALE;
//        }
//        Member member = new Member(name, age, sex);
//        manageLib.editMember(memberShipNo, member);
//        System.out.println("your information edited");
//        }
//
//        Member[] showAllTheMembers(Member[] members) {
//        int count = countElements(members);
//        Member[] existsMembers = new Member[count];
//        for (int i = 0; i < members.length; i++) {
//        for (int j = i; j < count; j++) {
//
//        if (members[i] != null) {
//        existsMembers[j] = members[i];
//        }
//        }
//        }
//        return existsMembers;
//        }
//
