import java.util.Arrays;
import java.util.Scanner;

class Oprator {
    public static Scanner input=new Scanner(System.in);

    static Book[] books=new Book[10];
    static Member[] members=new Member[10];

    static int memberCounter =1;
    static int bookCounter=1;

    public static void showMenu(){
        System.out.println("1 for Create Member\n2 for Show Member\n3 for Update Member\n" +
                "4 for Delete Member\n\n5 for Create Book\n6 for Show Book\n7 for Update Book\n8 for Delete Book\n" +
                "\n0 for Exit");

    }

    public static void CreateMember( ){
            Member member=new Member();
            System.out.println("enter name");
            member.memberName=input.next();
            System.out.println("enter age");
            member.age=input.nextInt();
            System.out.println("enter 0 for female , 1 for male");
            member.gender=input.nextInt();
            member.memberExistance=true;
            member.memberId=(memberCounter);
            System.out.println("ID is : "+member.memberId);
            AddMember(member);
    }
    public static void AddMember(Member member){
    members[member.memberId]=member;
        System.out.println(members[member.memberId]);
        memberCounter++;
    }

    public void ShowMember(){
        System.out.println("Press id to show");
        int j=input.nextInt();
        if(members[j].memberExistance) {
            System.out.println("name : " + members[j].memberName);
            System.out.println("age : " + members[j].age);
            System.out.println("gender : "+members[j].gender);
            System.out.println("id : "+members[j].memberId);
            System.out.println();
        }
        //doros kar nemikone
        if(!(members[j].memberExistance)){
            System.out.println("you id wasnt found\n");
        }
    }
//
    public void UpdateMember(){
        System.out.println("enter id");
        int j=input.nextInt();
        if(members[j].memberExistance){
            System.out.println("enter name");
            members[j].memberName=input.next();
            System.out.println("enter age");
            members[j].age=input.nextInt();
            System.out.println("enter 0 for female , 1 for male");
            members[j].gender=input.nextInt();
            members[j].memberExistance=true;}
        else if(!members[j].memberExistance){
            System.out.println("id wasnt exist\n");}
    }
//
    public void DeleteMember(){
        System.out.println("enter id");
        int j=input.nextInt();
        if(members[j].memberExistance){
            members[j].memberName=null;
            members[j].age=0;
            members[j].gender=0;
            members[j].memberExistance=false;}
        else if(!members[j].memberExistance){
            System.out.println("id wasnt exist\n");}
    }
    public  void CreateBook(){
            Book book=new Book();
            System.out.println("enter Book Name");
            book.bookName=input.next();
            book.bookExistance=true;
            book.bookId=bookCounter;
            System.out.println("Book ID is : "+bookCounter);
            AddBook(book);
        }

        public static void AddBook(Book book){
        books[book.bookId]=book;
        System.out.println(books[book.bookId]);
        bookCounter++;
    }


    public void ShowBook(){
        System.out.println("Press Book id to show");
        int z=input.nextInt();
        if(books[z].bookExistance) {
            System.out.println("Bookname : " + books[z].bookName);
            System.out.println("id : "+books[z].bookId);
            System.out.println();
        }
        else{
            System.out.println("Book ID wasnt exist\n");
        }
    }
//
    public void UpdateBook(){
        System.out.println("enter id");
        int z=input.nextInt();
        if(books[z].bookExistance){
            System.out.println("enter bookName");
            books[z].bookName=input.next();
            books[z].bookExistance=true;}
        else if(!(books[z].bookExistance)){
            System.out.println("Book ID wasnt exist\n");}
    }

    public void DeleteBook(){
        System.out.println("enter bookId");
        int z=input.nextInt();
        if(books[z].bookExistance){
            books[z].bookName=null;
            books[z].bookExistance=false;}
        else if(!books[z].bookExistance){
            System.out.println("Book ID wasnt exist\n");}
    }
}