import java.util.Scanner;
public class Main {
    public static Scanner input=new Scanner(System.in);

    public static void main(String[] args) {
        Oprator oprator=new Oprator();

        boolean exit=true;
        do {
            oprator.showMenu();
            int selectMenu=input.nextInt();
            if (selectMenu==1)oprator.CreateMember();
            if (selectMenu==2)oprator.ShowMember();
            if (selectMenu==3)oprator.UpdateMember();
            if (selectMenu==4)oprator.DeleteMember();
            if (selectMenu==5)oprator.CreateBook();
            if (selectMenu==6)oprator.ShowBook();
            if (selectMenu==7)oprator.UpdateBook();
            if (selectMenu==8)oprator.DeleteBook();
            if (selectMenu==0){exit=false; return;}
        }while(exit);
    }
}