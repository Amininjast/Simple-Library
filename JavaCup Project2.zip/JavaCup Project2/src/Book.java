public class Book {
    static int maxBook;
    int bookId;
    public String bookName;
    boolean bookExistance;

    public static int getMaxBook() {
        return maxBook;
    }

    public static void setMaxBook(int maxBook) {
        Book.maxBook = maxBook;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getBookName() {
        return bookName;
    }

    public void setBookName(String bookName) {
        this.bookName = bookName;
    }

    public boolean isBookExistance() {
        return bookExistance;
    }

    public void setBookExistance(boolean bookExistance) {
        this.bookExistance = bookExistance;
    }

    @Override
    public String toString() {
        return "Book{" +
                "bookId=" + bookId +
                ", bookName='" + bookName + '\'' +
                ", bookExistance=" + bookExistance +
                '}';
    }
}
