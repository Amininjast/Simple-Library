public class Member {
    int maxmember;
    int memberId;
    int age;
    int gender;
    String memberName;
    boolean memberExistance;

    public int getMaxmember() {
        return maxmember;
    }

    public void setMaxmember(int maxmember) {
        this.maxmember = maxmember;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getGender() {
        return gender;
    }

    public void setGender(int gender) {
        this.gender = gender;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public boolean isMemberExistance() {
        return memberExistance;
    }

    public void setMemberExistance(boolean memberExistance) {
        this.memberExistance = memberExistance;
    }

    @Override
    public String toString() {
        return "Member{" +
                "maxmember=" + maxmember +
                ", memberId=" + memberId +
                ", age=" + age +
                ", gender=" + gender +
                ", memberName='" + memberName + '\'' +
                ", memberExistance=" + memberExistance +
                '}';
    }
}

